import QtQuick
import QtQuick.Window
import Qt.labs.folderlistmodel
import QtGraphicalEffects
import SddmComponents 2.0

Rectangle {
    MouseArea { anchors.fill: parent; cursorShape: Qt.ArrowCursor; z: -1 }

    id: root
    width: Screen.width; height: Screen.height
    readonly property real s: height / 768
    color: "#000000"

    property color cInk:   "#ffffff"
    property color cDim:   "#555555"
    property color cFaint: "#1c1c1c"
    property color cRule:  "#1e1e1e"
    property color cHint:  "#333333"

    function loadColors() {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "file:///home/unc/.cache/dingaling/colors.json", false);
        try {
            xhr.send();
            if (xhr.status === 200 || xhr.status === 0) {
                var d = JSON.parse(xhr.responseText);
                if (d.cream)                     cInk   = d.cream;
                if (d.dim)                       cDim   = d.dim;
                if (d.surface_container_high)    cFaint = d.surface_container_high;
                if (d.outline_variant)           cRule  = d.outline_variant;
                if (d.subtle)                    cHint  = d.subtle;
            }
        } catch (e) {}
    }

    property string mode: "login"
    property string cmdBuf: ""

    property real uiClock:  0
    property real uiLogin:  0
    property real uiBottom: 0

    FolderListModel { id: fontFolder; folder: Qt.resolvedUrl("font"); nameFilters: ["*.ttf","*.otf"] }
    FontLoader { source: fontFolder.count > 0 ? "font/" + fontFolder.get(0,"fileName") : "" }
    TextConstants { id: textConstants }

    Timer { interval: 100; running: true; onTriggered: pwd.forceActiveFocus() }
    Component.onCompleted: { loadColors(); clockAnim.start(); keyboard.numLock = true }
    NumberAnimation { id: clockAnim;  target: root; property: "uiClock";  from: 0; to: 1; duration: 900; easing.type: Easing.OutCubic; onStopped: loginAnim.start() }
    NumberAnimation { id: loginAnim;  target: root; property: "uiLogin";  from: 0; to: 1; duration: 700; easing.type: Easing.OutCubic; onStopped: bottomAnim.start() }
    NumberAnimation { id: bottomAnim; target: root; property: "uiBottom"; from: 0; to: 1; duration: 500; easing.type: Easing.OutCubic }

    Image {
        id: bgImage
        anchors.fill: parent; source: "bg.jpg"; fillMode: Image.PreserveAspectCrop; asynchronous: true; visible: false
    }

    FastBlur {
        anchors.fill: parent; source: bgImage; radius: 64; opacity: root.uiClock
    }

    Rectangle {
        id: scanLine; width: parent.width; height: 1 * s; color: "#ffffff"; opacity: 0.035; y: -height
        NumberAnimation on y { from: -scanLine.height; to: root.height; duration: 1800; easing.type: Easing.InOutSine; running: true }
    }

    Rectangle { anchors.fill: parent; visible: root.uiClock < 1.0; opacity: 1.0 - root.uiClock; color: "#000000"; z: 100 }

    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.35)
    }

    Item {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -220 * s
        opacity: root.uiClock

        Column {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 0

            Text {
                id: clockText
                anchors.horizontalCenter: parent.horizontalCenter
                text: Qt.formatTime(new Date(), "HH:mm")
                color: root.cInk
                font.family: "JetBrainsMono Nerd Font"
                font.pixelSize: 100 * s
                font.weight: Font.Bold; font.letterSpacing: -1 * s; lineHeight: 0.92
                Timer { interval: 1000; running: true; repeat: true; onTriggered: clockText.text = Qt.formatTime(new Date(), "HH:mm") }
            }

            Rectangle {
                anchors.horizontalCenter: parent.horizontalCenter
                width: clockText.width; height: 1 * s; color: root.cInk
            }

            Item { width: 1; height: 12 * s }

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: Qt.formatDate(new Date(), "dddd, MMMM d").toUpperCase()
                color: root.cInk
                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 10 * s
                font.letterSpacing: 4 * s; font.weight: Font.Bold
            }
        }
    }

    Item {
        id: bellyArea
        z: 6
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: 10 * s
        width: 260 * s
        height: centerCol.implicitHeight
        opacity: root.uiLogin

        Column {
            id: centerCol; width: parent.width; spacing: 0

            Rectangle {
                width: parent.width; height: 42 * s
                radius: 21 * s
                color: root.cFaint
                visible: root.mode === "login"
                border.color: pwd.activeFocus ? "#404040" : "transparent"
                border.width: 1 * s
                Behavior on border.color { ColorAnimation { duration: 200 } }

                TextInput {
                    id: pwd
                    anchors.fill: parent
                    anchors.leftMargin: 16 * s; anchors.rightMargin: 16 * s
                    horizontalAlignment: TextInput.AlignHCenter
                    verticalAlignment: TextInput.AlignVCenter
                    echoMode: TextInput.Password
                    passwordCharacter: "•"
                    color: root.cInk
                    font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 16 * s
                    font.letterSpacing: 4 * s; font.weight: Font.Bold
                    focus: root.mode === "login"; clip: true
                    cursorVisible: false
                    cursorDelegate: Item { width: 0; height: 0 }
                    onAccepted: doLogin()

                    Keys.onPressed: function(ev) {
                        if (ev.key === Qt.Key_Colon) {
                            ev.accepted = true
                            pwd.text = ""; root.cmdBuf = ""
                            root.mode = "cmd"; cmdInput.forceActiveFocus()
                        }
                    }

                    Rectangle {
                        id: cursor; width: 1 * s; height: 16 * s; color: root.cInk
                        anchors.verticalCenter: parent.verticalCenter
                        x: pwd.cursorRectangle.x
                        visible: pwd.focus && pwd.text.length === 0
                        SequentialAnimation {
                            loops: Animation.Infinite; running: cursor.visible
                            NumberAnimation { target: cursor; property: "opacity"; from: 1.0; to: 0.0; duration: 500 }
                            NumberAnimation { target: cursor; property: "opacity"; from: 0.0; to: 1.0; duration: 500 }
                        }
                    }
                }
                MouseArea { anchors.fill: parent; cursorShape: Qt.ArrowCursor; onClicked: pwd.forceActiveFocus() }
            }

            Item {
                width: parent.width; height: 42 * s
                visible: root.mode === "cmd"
                Row {
                    anchors.left: parent.left; anchors.leftMargin: 4 * s
                    anchors.verticalCenter: parent.verticalCenter; spacing: 0
                    Text {
                        text: ":"
                        color: root.cInk
                        font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 18 * s
                        font.weight: Font.Bold; anchors.verticalCenter: parent.verticalCenter
                    }
                    TextInput {
                        id: cmdInput; width: 220 * s
                        anchors.verticalCenter: parent.verticalCenter
                        color: root.cInk
                        font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 18 * s
                        font.weight: Font.Bold; font.letterSpacing: 1 * s
                        text: root.cmdBuf; focus: root.mode === "cmd"
                        clip: true; cursorVisible: true
                        onTextChanged: root.cmdBuf = text
                        Keys.onPressed: function(ev) {
                            if (ev.key === Qt.Key_Escape) {
                                ev.accepted = true
                                root.mode = "login"; root.cmdBuf = ""
                                cmdInput.text = ""; cmdFeedback.text = ""
                                pwd.forceActiveFocus()
                            } else if (ev.key === Qt.Key_Return || ev.key === Qt.Key_Enter) {
                                ev.accepted = true
                                execCmd(root.cmdBuf.trim().toLowerCase())
                            }
                        }
                    }
                }
                Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1 * s; color: root.cHint }
            }

            Text {
                id: errorMsg; anchors.horizontalCenter: parent.horizontalCenter
                text: ""; color: root.cDim
                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 10 * s
                font.letterSpacing: 2 * s; font.weight: Font.Bold
                visible: text !== "" && root.mode === "login"
                topPadding: 8 * s
            }
            Text {
                id: cmdFeedback; anchors.horizontalCenter: parent.horizontalCenter
                text: ""; color: root.cDim
                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 10 * s
                font.letterSpacing: 2 * s; font.weight: Font.Bold
                visible: text !== ""
                topPadding: 8 * s
            }
        }
    }

    Item {
        z: 6
        anchors.left: parent.left; anchors.right: parent.right
        anchors.bottom: parent.bottom; anchors.bottomMargin: 40 * s
        height: 20 * s; opacity: root.uiBottom

        Row {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.verticalCenter: parent.verticalCenter
            spacing: 20 * s
            Repeater {
                model: [
                    { key: ":r", label: "reboot"  },
                    { key: ":p", label: "power"   }
                ]
                delegate: Row {
                    spacing: 5 * s; anchors.verticalCenter: parent.verticalCenter
                    Rectangle {
                        width: keyLbl.width + 8 * s; height: 14 * s
                        radius: 2 * s; color: root.cFaint; anchors.verticalCenter: parent.verticalCenter
                        Text { id: keyLbl; anchors.centerIn: parent; text: modelData.key; color: root.cDim
                            font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 9 * s; font.weight: Font.Bold }
                    }
                    Text { anchors.verticalCenter: parent.verticalCenter; text: modelData.label; color: root.cHint
                        font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 9 * s
                        font.letterSpacing: 1 * s; font.weight: Font.Bold }
                }
            }
        }

        Text {
            anchors.right: parent.right; anchors.rightMargin: 52 * s
            anchors.verticalCenter: parent.verticalCenter
            text: root.mode === "cmd" ? "COMMAND" : "INSERT"
            color: root.cHint
            font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 9 * s
            font.letterSpacing: 3 * s; font.weight: Font.Bold
        }
    }

    Connections {
        target: typeof sddm !== "undefined" ? sddm : null
        function onLoginFailed() {
            errorMsg.text = "incorrect password"
            pwd.text = ""; root.mode = "login"; pwd.forceActiveFocus()
            shakeAnim.start()
        }
    }

    SequentialAnimation {
        id: shakeAnim
        NumberAnimation { target: bellyArea; property: "anchors.horizontalCenterOffset"; from: 0;    to:  8*s; duration: 50 }
        NumberAnimation { target: bellyArea; property: "anchors.horizontalCenterOffset"; from: 8*s;  to: -8*s; duration: 80 }
        NumberAnimation { target: bellyArea; property: "anchors.horizontalCenterOffset"; from: -8*s; to:  5*s; duration: 70 }
        NumberAnimation { target: bellyArea; property: "anchors.horizontalCenterOffset"; from: 5*s;  to:  0;   duration: 60 }
    }

    function execCmd(cmd) {
        if (cmd === "r" || cmd === "reboot") {
            if (typeof sddm !== "undefined") sddm.reboot()
            else { cmdFeedback.text = "reboot"; root.mode = "login"; pwd.forceActiveFocus() }
        } else if (cmd === "p" || cmd === "power" || cmd === "q" || cmd === "quit") {
            if (typeof sddm !== "undefined") sddm.powerOff()
            else { cmdFeedback.text = "power off"; root.mode = "login"; pwd.forceActiveFocus() }
        } else if (cmd === "") {
            root.mode = "login"; root.cmdBuf = ""; cmdInput.text = ""
            cmdFeedback.text = ""; pwd.forceActiveFocus()
        } else {
            cmdFeedback.text = "E492: not a command: " + cmd
            root.mode = "login"; root.cmdBuf = ""; cmdInput.text = ""
            pwd.forceActiveFocus()
        }
    }

    function doLogin() {
        var u = typeof userModel !== "undefined" ? userModel.lastUser : ""
        if (typeof sddm !== "undefined") sddm.login(u, pwd.text, 0)
    }
}
