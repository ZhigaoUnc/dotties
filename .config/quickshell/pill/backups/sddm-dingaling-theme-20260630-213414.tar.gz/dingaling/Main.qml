import QtQuick 2.15
import QtQuick.Window 2.15
import Qt.labs.folderlistmodel 2.15
import QtGraphicalEffects 1.0
import SddmComponents 2.0

Rectangle {
    MouseArea { anchors.fill: parent; cursorShape: Qt.ArrowCursor; z: -1 }

    id: root
    width: Screen.width; height: Screen.height
    readonly property real s: height / 768
    color: "#000000"

    // ── Palette ────────────────────────────────────────────────
    property color cInk:   "#ffffff"
    property color cDim:   "#555555"
    property color cFaint: "#1c1c1c"
    property color cRule:  "#1e1e1e"
    property color cHint:  "#333333"

    function loadColors() {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "colors.json", false);
        try {
            xhr.send();
            if (xhr.status === 200 || xhr.status === 0) {
                var d = JSON.parse(xhr.responseText);
                if (d.cream)                     cInk   = d.cream;
                if (d.dim)                       cDim   = d.dim;
                if (d.surface_container_high)    cFaint = d.surface_container_high;
                if (d.outline_variant)           cRule  = d.outline_variant;
                if (d.subtle)                    cHint  = d.subtle;
            }
        } catch (e) {}
    }

    // ── State ──────────────────────────────────────────────────
    property int sessionIndex: (typeof sessionModel !== "undefined" && sessionModel.lastIndex >= 0) ? sessionModel.lastIndex : 0
    property int userIndex:    (typeof userModel    !== "undefined" && userModel.lastIndex    >= 0) ? userModel.lastIndex    : 0

    // mode: "login" | "cmd" | "session-pick" | "user-pick"
    property string mode: "login"
    property string cmdBuf: ""

    property int    pickCursor: 0
    property string pickQuery:  ""

    property real uiClock:  0
    property real uiLogin:  0
    property real uiBottom: 0

    // bg blur opacity — animates to 1 when picker opens
    property real bgDim: 0
    Behavior on bgDim { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }

    // vertical offset for the login block — slides down when picker opens
    property real loginOffset: 10
    Behavior on loginOffset { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }

    // ── Assets ─────────────────────────────────────────────────
    FolderListModel { id: fontFolder; folder: Qt.resolvedUrl("font"); nameFilters: ["*.ttf","*.otf"] }
    FontLoader { source: fontFolder.count > 0 ? "font/" + fontFolder.get(0,"fileName") : "" }
    TextConstants { id: textConstants }

    ListModel { id: sessionListModel }
    ListModel { id: userListModel }
    ListModel { id: filteredModel }

    ListView {
        id: sessionHelper; model: typeof sessionModel !== "undefined" ? sessionModel : null
        currentIndex: root.sessionIndex; opacity: 0; width: 1; height: 1
        delegate: Item { property string sName: model.name || "" }
    }
    ListView {
        id: userHelper; model: typeof userModel !== "undefined" ? userModel : null
        currentIndex: root.userIndex; opacity: 0; width: 1; height: 1
        delegate: Item {
            property string uName:  model.realName || model.name || ""
            property string uLogin: model.name || ""
        }
    }

    // ── Helpers ────────────────────────────────────────────────
    function sessionName(i) {
        if (typeof sessionModel === "undefined") return "Session " + i
        try {
            var item = sessionModel.get(i)
            if (item && item.name) return item.name
        } catch (e) {}
        var val = sessionModel.data(sessionModel.index(i, 0), Qt.UserRole + 4)
        if (typeof val === "string" && val !== "") return val
        return "Session " + i
    }

    function fuzzyMatch(str, query) {
        if (query === "") return true
        var s = str.toLowerCase(), q = query.toLowerCase()
        var si = 0, qi = 0
        while (si < s.length && qi < q.length) { if (s[si] === q[qi]) qi++; si++ }
        return qi === q.length
    }

    function rebuildFilter() {
        filteredModel.clear()
        var src = (root.mode === "session-pick") ? sessionListModel : userListModel
        for (var i = 0; i < src.count; i++) {
            var item = src.get(i)
            if (fuzzyMatch(item.name, root.pickQuery))
                filteredModel.append({ name: item.name, login: item.login || "", srcIndex: i })
        }
        root.pickCursor = 0
    }

    // ── Boot ───────────────────────────────────────────────────
    Timer { interval: 100; running: true; onTriggered: pwd.forceActiveFocus() }
    Component.onCompleted: {
        loadColors()
        clockAnim.start()
        keyboard.numLock = true

        // Load sessions with aggressive debugging
        console.log("=== SESSION MODEL DEBUG ===")
        console.log("typeof sessionModel: " + (typeof sessionModel))
        
        if (typeof sessionModel !== "undefined") {
            console.log("sessionModel exists")
            console.log("sessionModel.rowCount type: " + (typeof sessionModel.rowCount))
            
            if (sessionModel.rowCount) {
                var rowCount = sessionModel.rowCount()
                console.log("sessionModel.rowCount(): " + rowCount)
                
                if (rowCount > 0) {
                    console.log("✓ Loading " + rowCount + " sessions from SDDM")
                    for (var i = 0; i < rowCount; i++) {
                        var name = sessionName(i)
                        console.log("  [" + i + "] " + name)
                        sessionListModel.append({ name: name, login: "" })
                    }
                } else {
                    console.log("✗ sessionModel.rowCount() returned 0 or falsy")
                    console.log("Using fallback sessions")
                    sessionListModel.append({ name: "Hyprland",   login: "" })
                    sessionListModel.append({ name: "Sway",       login: "" })
                    sessionListModel.append({ name: "GNOME",      login: "" })
                    sessionListModel.append({ name: "KDE Plasma", login: "" })
                    sessionListModel.append({ name: "Scroll",     login: "" })
                }
            } else {
                console.log("✗ sessionModel.rowCount is not a function")
                console.log("Trying to access model as ListModel...")
                try {
                    var sc = sessionModel.count
                    console.log("sessionModel.count: " + sc)
                    if (sc > 0) {
                        for (var j = 0; j < sc; j++) {
                            var item = sessionModel.get(j)
                            console.log("  [" + j + "] name=" + item.name)
                            sessionListModel.append({ name: item.name, login: "" })
                        }
                    } else {
                        throw "count is 0"
                    }
                } catch (e) {
                    console.log("✗ ListModel access failed: " + e)
                    console.log("Using fallback sessions")
                    sessionListModel.append({ name: "Hyprland",   login: "" })
                    sessionListModel.append({ name: "Sway",       login: "" })
                    sessionListModel.append({ name: "GNOME",      login: "" })
                    sessionListModel.append({ name: "KDE Plasma", login: "" })
                    sessionListModel.append({ name: "Scroll",     login: "" })
                }
            }
        } else {
            console.log("✗ sessionModel is undefined")
            console.log("Using fallback sessions")
            sessionListModel.append({ name: "Hyprland",   login: "" })
            sessionListModel.append({ name: "Sway",       login: "" })
            sessionListModel.append({ name: "GNOME",      login: "" })
            sessionListModel.append({ name: "KDE Plasma", login: "" })
            sessionListModel.append({ name: "Scroll",     login: "" })
        }

        // Load users with logging
        console.log("=== USER MODEL DEBUG ===")
        console.log("typeof userModel: " + (typeof userModel))
        
        if (typeof userModel !== "undefined") {
            console.log("userModel exists")
            console.log("userModel.rowCount type: " + (typeof userModel.rowCount))
            
            if (userModel.rowCount) {
                var userRowCount = userModel.rowCount()
                console.log("userModel.rowCount(): " + userRowCount)
                
                if (userRowCount > 0) {
                    console.log("✓ Loading " + userRowCount + " users from SDDM")
                    for (var j = 0; j < userRowCount; j++) {
                        var rn = userModel.data(userModel.index(j, 0), 259)
                        var ln = userModel.data(userModel.index(j, 0), 257)
                        var userName = rn || ln || ("User " + j)
                        var loginName = ln || ("user" + j)
                        console.log("  [" + j + "] " + userName + " (" + loginName + ")")
                        userListModel.append({ name: userName, login: loginName })
                    }
                } else {
                    console.log("✗ userModel.rowCount() returned 0")
                    userListModel.append({ name: "zaddy", login: "zaddy" })
                }
            } else {
                console.log("✗ userModel.rowCount is not a function")
                userListModel.append({ name: "zaddy", login: "zaddy" })
            }
        } else {
            console.log("✗ userModel is undefined")
            userListModel.append({ name: "zaddy", login: "zaddy" })
        }
    }

    NumberAnimation { id: clockAnim;  target: root; property: "uiClock";  from: 0; to: 1; duration: 900; easing.type: Easing.OutCubic; onStopped: loginAnim.start() }
    NumberAnimation { id: loginAnim;  target: root; property: "uiLogin";  from: 0; to: 1; duration: 700; easing.type: Easing.OutCubic; onStopped: bottomAnim.start() }
    NumberAnimation { id: bottomAnim; target: root; property: "uiBottom"; from: 0; to: 1; duration: 500; easing.type: Easing.OutCubic }

    // ── Background ──────────────────────────────────────────────
    Image {
        id: bgImage
        anchors.fill: parent; source: "bg.png"; fillMode: Image.PreserveAspectCrop; asynchronous: true; visible: false
    }

    FastBlur {
        anchors.fill: parent; source: bgImage; radius: 64
    }

    // ── Scan-line ──────────────────────────────────────────────
    Rectangle {
        id: scanLine; width: parent.width; height: 1 * s; color: "#ffffff"; opacity: 0.035; y: -height
        NumberAnimation on y { from: -scanLine.height; to: root.height; duration: 1800; easing.type: Easing.InOutSine; running: true }
    }

    // ── Blackout (boot) ────────────────────────────────────────
    Rectangle { anchors.fill: parent; visible: root.uiClock < 1.0; opacity: 1.0 - root.uiClock; color: "#000000"; z: 100 }

    // ══════════════════════════════════════════════════════════
    // CLOCK
    // ══════════════════════════════════════════════════════════
    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.35)
    }

    Item {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -220 * s
        opacity: root.uiClock * (1.0 - root.bgDim * 0.85)

        Column {
            anchors.horizontalCenter: parent.horizontalCenter
            spacing: 0

            Text {
                id: clockText
                anchors.horizontalCenter: parent.horizontalCenter
                text: Qt.formatTime(new Date(), "HH:mm")
                color: root.cInk
                font.family: "JetBrainsMono Nerd Font"
                font.pixelSize: 100 * s
                font.weight: Font.Bold; font.letterSpacing: -1 * s; lineHeight: 0.92
                Timer { interval: 1000; running: true; repeat: true; onTriggered: clockText.text = Qt.formatTime(new Date(), "HH:mm") }
            }

            Rectangle {
                anchors.horizontalCenter: parent.horizontalCenter
                width: clockText.width; height: 1 * s; color: root.cInk
            }

            Item { width: 1; height: 12 * s }

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: Qt.formatDate(new Date(), "dddd, MMMM d").toUpperCase()
                color: root.cInk
                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 10 * s
                font.letterSpacing: 4 * s; font.weight: Font.Bold
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    // BG DIMMER (over everything except the picker panel)
    // ══════════════════════════════════════════════════════════
    Rectangle {
        anchors.fill: parent
        color: "#000000"
        opacity: root.bgDim * 0.72
        z: 5
        visible: root.bgDim > 0
    }

    // ══════════════════════════════════════════════════════════
    // CENTER AREA  (z:6 so it sits above the dimmer)
    // ══════════════════════════════════════════════════════════
    Item {
        id: bellyArea
        z: 6
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: root.loginOffset * s
        width: 260 * s
        height: centerCol.implicitHeight
        opacity: root.uiLogin
        focus: root.mode === "session-pick" || root.mode === "user-pick"

        // ── Picker key nav ─────────────────────────────────────
        Keys.onPressed: function(ev) {
            if (root.mode !== "session-pick" && root.mode !== "user-pick") return
            if (ev.key === Qt.Key_Down) {
                ev.accepted = true
                if (filteredModel.count > 0) root.pickCursor = (root.pickCursor + 1) % filteredModel.count
            } else if (ev.key === Qt.Key_Up) {
                ev.accepted = true
                if (filteredModel.count > 0) root.pickCursor = (root.pickCursor - 1 + filteredModel.count) % filteredModel.count
            } else if (ev.key === Qt.Key_J && (ev.modifiers & Qt.ControlModifier)) {
                ev.accepted = true
                if (filteredModel.count > 0) root.pickCursor = (root.pickCursor + 1) % filteredModel.count
            } else if (ev.key === Qt.Key_K && (ev.modifiers & Qt.ControlModifier)) {
                ev.accepted = true
                if (filteredModel.count > 0) root.pickCursor = (root.pickCursor - 1 + filteredModel.count) % filteredModel.count
            } else if (ev.key === Qt.Key_H && (ev.modifiers & Qt.ControlModifier)) {
                ev.accepted = true; closePicker()
            } else if (ev.key === Qt.Key_L && (ev.modifiers & Qt.ControlModifier)) {
                ev.accepted = true; commitPick()
            } else if (ev.key === Qt.Key_Return || ev.key === Qt.Key_Enter) {
                ev.accepted = true; commitPick()
            } else if (ev.key === Qt.Key_Escape) {
                ev.accepted = true; closePicker()
            } else if (ev.key === Qt.Key_Backspace) {
                ev.accepted = true
                if (root.pickQuery.length > 0) { root.pickQuery = root.pickQuery.slice(0, -1); rebuildFilter() }
            } else if (ev.text && ev.text.length === 1 && ev.key !== Qt.Key_Colon) {
                ev.accepted = true; root.pickQuery += ev.text; rebuildFilter()
            }
        }

        Column {
            id: centerCol; width: parent.width; spacing: 0

            // ── User label ─────────────────────────────────────
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: {
                    var ul = userListModel.count > root.userIndex
                        ? userListModel.get(root.userIndex).login
                        : (typeof userModel !== "undefined" ? userModel.lastUser : "user")
                    return ul.toLowerCase()
                }
                color: root.cHint
                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 10 * s
                font.letterSpacing: 3 * s; font.weight: Font.Bold
                visible: root.mode === "login"
                bottomPadding: 6 * s
            }

            // ── Password box ───────────────────────────────────
            Rectangle {
                width: parent.width; height: 42 * s
                radius: 21 * s          // fully rounded pill
                color: root.cFaint
                visible: root.mode === "login"
                border.color: pwd.activeFocus ? "#404040" : "transparent"
                border.width: 1 * s
                Behavior on border.color { ColorAnimation { duration: 200 } }

                TextInput {
                    id: pwd
                    anchors.fill: parent
                    anchors.leftMargin: 16 * s; anchors.rightMargin: 16 * s
                    horizontalAlignment: TextInput.AlignHCenter
                    verticalAlignment: TextInput.AlignVCenter
                    echoMode: TextInput.Password
                    passwordCharacter: "•"
                    color: root.cInk
                    font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 16 * s
                    font.letterSpacing: 4 * s; font.weight: Font.Bold
                    focus: root.mode === "login"; clip: true
                    cursorVisible: false
                    cursorDelegate: Item { width: 0; height: 0 }
                    onAccepted: doLogin()

                    Keys.onPressed: function(ev) {
                        if (ev.key === Qt.Key_Colon) {
                            ev.accepted = true
                            pwd.text = ""; root.cmdBuf = ""
                            root.mode = "cmd"; cmdInput.forceActiveFocus()
                        }
                    }

                    Rectangle {
                        id: cursor; width: 1 * s; height: 16 * s; color: root.cInk
                        anchors.verticalCenter: parent.verticalCenter
                        x: pwd.cursorRectangle.x
                        visible: pwd.focus && pwd.text.length === 0
                        SequentialAnimation {
                            loops: Animation.Infinite; running: cursor.visible
                            NumberAnimation { target: cursor; property: "opacity"; from: 1.0; to: 0.0; duration: 500 }
                            NumberAnimation { target: cursor; property: "opacity"; from: 0.0; to: 1.0; duration: 500 }
                        }
                    }
                }
                MouseArea { anchors.fill: parent; cursorShape: Qt.ArrowCursor; onClicked: pwd.forceActiveFocus() }
            }

            // ── Command line ───────────────────────────────────
            Item {
                width: parent.width; height: 42 * s
                visible: root.mode === "cmd"
                Row {
                    anchors.left: parent.left; anchors.leftMargin: 4 * s
                    anchors.verticalCenter: parent.verticalCenter; spacing: 0
                    Text {
                        text: ":"
                        color: root.cInk
                        font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 18 * s
                        font.weight: Font.Bold; anchors.verticalCenter: parent.verticalCenter
                    }
                    TextInput {
                        id: cmdInput; width: 220 * s
                        anchors.verticalCenter: parent.verticalCenter
                        color: root.cInk
                        font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 18 * s
                        font.weight: Font.Bold; font.letterSpacing: 1 * s
                        text: root.cmdBuf; focus: root.mode === "cmd"
                        clip: true; cursorVisible: true
                        onTextChanged: root.cmdBuf = text
                        Keys.onPressed: function(ev) {
                            if (ev.key === Qt.Key_Escape) {
                                ev.accepted = true
                                root.mode = "login"; root.cmdBuf = ""
                                cmdInput.text = ""; cmdFeedback.text = ""
                                pwd.forceActiveFocus()
                            } else if (ev.key === Qt.Key_Return || ev.key === Qt.Key_Enter) {
                                ev.accepted = true
                                execCmd(root.cmdBuf.trim().toLowerCase())
                            }
                        }
                    }
                }
                Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1 * s; color: root.cHint }
            }

            // ── Errors / feedback ──────────────────────────────
            Text {
                id: errorMsg; anchors.horizontalCenter: parent.horizontalCenter
                text: ""; color: root.cDim
                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 10 * s
                font.letterSpacing: 2 * s; font.weight: Font.Bold
                visible: text !== "" && root.mode === "login"
                topPadding: 8 * s
            }
            Text {
                id: cmdFeedback; anchors.horizontalCenter: parent.horizontalCenter
                text: ""; color: root.cDim
                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 10 * s
                font.letterSpacing: 2 * s; font.weight: Font.Bold
                visible: text !== "" && root.mode !== "session-pick" && root.mode !== "user-pick"
                topPadding: 8 * s
            }

            // ── PICKER — below the password field ─────────────
            Item {
                width: parent.width
                height: pickerVisible ? pickerInner.implicitHeight + 20 * s : 0
                visible: pickerVisible
                clip: true
                property bool pickerVisible: root.mode === "session-pick" || root.mode === "user-pick"
                Behavior on height { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

                Column {
                    id: pickerInner
                    width: parent.width
                    anchors.top: parent.top; anchors.topMargin: 14 * s
                    spacing: 0

                    // Search row
                    Item {
                        width: parent.width; height: 28 * s
                        Row {
                            anchors.left: parent.left; anchors.leftMargin: 8 * s
                            anchors.verticalCenter: parent.verticalCenter; spacing: 6 * s
                            Text {
                                text: "/"; color: root.cDim
                                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 12 * s
                                font.weight: Font.Bold; anchors.verticalCenter: parent.verticalCenter
                            }
                            Text {
                                text: root.pickQuery === ""
                                    ? (root.mode === "session-pick" ? "filter session…" : "filter user…")
                                    : root.pickQuery
                                color: root.pickQuery === "" ? root.cHint : root.cInk
                                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 11 * s
                                font.letterSpacing: 1 * s; anchors.verticalCenter: parent.verticalCenter
                            }
                        }
                        Rectangle { anchors.bottom: parent.bottom; width: parent.width; height: 1 * s; color: root.cRule }
                    }

                    // Results list
                    Repeater {
                        model: filteredModel
                        delegate: Item {
                            width: parent.width; height: 28 * s
                            property bool isCurrent: index === root.pickCursor

                            Rectangle {
                                anchors.fill: parent
                                anchors.leftMargin: 2 * s; anchors.rightMargin: 2 * s
                                color: isCurrent ? "#222222" : "transparent"; radius: 4 * s
                            }

                            Row {
                                anchors.verticalCenter: parent.verticalCenter
                                anchors.left: parent.left; anchors.leftMargin: 10 * s
                                spacing: 8 * s
                                Text {
                                    text: isCurrent ? "›" : " "; color: root.cInk
                                    font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 13 * s
                                    font.weight: Font.Bold; anchors.verticalCenter: parent.verticalCenter
                                }
                                Text {
                                    text: model.name
                                    color: isCurrent ? root.cInk : root.cDim
                                    font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 11 * s
                                    font.letterSpacing: 1 * s; anchors.verticalCenter: parent.verticalCenter
                                    Behavior on color { ColorAnimation { duration: 80 } }
                                }
                            }

                            Text {
                                anchors.right: parent.right; anchors.rightMargin: 12 * s
                                anchors.verticalCenter: parent.verticalCenter
                                text: (root.mode === "session-pick" && model.srcIndex === root.sessionIndex) ||
                                      (root.mode === "user-pick"    && model.srcIndex === root.userIndex)
                                      ? "·" : ""
                                color: root.cDim
                                font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 18 * s
                            }
                        }
                    }

                    // Empty state
                    Item {
                        width: parent.width; height: 28 * s
                        visible: filteredModel.count === 0
                        Text {
                            anchors.left: parent.left; anchors.leftMargin: 26 * s
                            anchors.verticalCenter: parent.verticalCenter
                            text: "no match"; color: root.cHint
                            font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 10 * s
                            font.letterSpacing: 1 * s
                        }
                    }

                    Item { width: 1; height: 6 * s }
                    Text {
                        anchors.left: parent.left; anchors.leftMargin: 10 * s
                        text: "j/k  ↵  esc  —  type to filter"
                        color: root.cHint
                        font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 8 * s
                        font.letterSpacing: 0.5 * s
                    }
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    // BOTTOM STATUS BAR  (z:6)
    // ══════════════════════════════════════════════════════════
    Item {
        z: 6
        anchors.left: parent.left; anchors.right: parent.right
        anchors.bottom: parent.bottom; anchors.bottomMargin: 40 * s
        height: 20 * s; opacity: root.uiBottom

        Text {
            anchors.left: parent.left; anchors.leftMargin: 52 * s
            anchors.verticalCenter: parent.verticalCenter
            text: sessionModel && sessionModel.rowCount && sessionModel.rowCount() > 0
                  ? sessionName(sessionModel.lastIndex).toLowerCase() : ""
            color: root.cHint
            font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 10 * s
            font.letterSpacing: 2 * s; font.weight: Font.Bold
        }

        Row {
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.verticalCenter: parent.verticalCenter
            spacing: 20 * s
            Repeater {
                model: [
                    { key: ":r", label: "reboot"  },
                    { key: ":p", label: "power"   },
                    { key: ":s", label: "session" },
                    { key: ":u", label: "user"    }
                ]
                delegate: Row {
                    spacing: 5 * s; anchors.verticalCenter: parent.verticalCenter
                    Rectangle {
                        width: keyLbl.width + 8 * s; height: 14 * s
                        radius: 2 * s; color: root.cFaint; anchors.verticalCenter: parent.verticalCenter
                        Text { id: keyLbl; anchors.centerIn: parent; text: modelData.key; color: root.cDim
                            font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 9 * s; font.weight: Font.Bold }
                    }
                    Text { anchors.verticalCenter: parent.verticalCenter; text: modelData.label; color: root.cHint
                        font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 9 * s
                        font.letterSpacing: 1 * s; font.weight: Font.Bold }
                }
            }
        }

        Text {
            anchors.right: parent.right; anchors.rightMargin: 52 * s
            anchors.verticalCenter: parent.verticalCenter
            text: root.mode === "cmd" ? "COMMAND"
                : (root.mode === "session-pick" || root.mode === "user-pick") ? "NORMAL"
                : "INSERT"
            color: root.cHint
            font.family: "JetBrainsMono Nerd Font"; font.pixelSize: 9 * s
            font.letterSpacing: 3 * s; font.weight: Font.Bold
        }
    }

    // ══════════════════════════════════════════════════════════
    // WIRING
    // ══════════════════════════════════════════════════════════
    Connections {
        target: typeof sddm !== "undefined" ? sddm : null
        function onLoginFailed() {
            errorMsg.text = "incorrect password"
            pwd.text = ""; root.mode = "login"; pwd.forceActiveFocus()
            shakeAnim.start()
        }
    }

    SequentialAnimation {
        id: shakeAnim
        NumberAnimation { target: bellyArea; property: "anchors.horizontalCenterOffset"; from: 0;    to:  8*s; duration: 50 }
        NumberAnimation { target: bellyArea; property: "anchors.horizontalCenterOffset"; from: 8*s;  to: -8*s; duration: 80 }
        NumberAnimation { target: bellyArea; property: "anchors.horizontalCenterOffset"; from: -8*s; to:  5*s; duration: 70 }
        NumberAnimation { target: bellyArea; property: "anchors.horizontalCenterOffset"; from: 5*s;  to:  0;   duration: 60 }
    }

    function openPicker(which) {
        root.cmdBuf = ""; cmdInput.text = ""
        root.pickQuery = ""; root.mode = which
        root.pickCursor = which === "session-pick" ? root.sessionIndex : root.userIndex
        rebuildFilter()
        root.bgDim = 1
        root.loginOffset = 60   // slide login block down
        bellyArea.forceActiveFocus()
    }

    function commitPick() {
        if (filteredModel.count === 0) { closePicker(); return }
        var item = filteredModel.get(root.pickCursor)
        if (root.mode === "session-pick") {
            root.sessionIndex = item.srcIndex
            sessionHelper.currentIndex = item.srcIndex
        } else {
            root.userIndex = item.srcIndex
            userHelper.currentIndex = item.srcIndex
        }
        closePicker()
    }

    function closePicker() {
        root.mode = "login"; root.pickQuery = ""; filteredModel.clear()
        root.bgDim = 0; root.loginOffset = 10
        pwd.forceActiveFocus()
    }

    function execCmd(cmd) {
        if      (cmd === "r" || cmd === "reboot") {
            if (typeof sddm !== "undefined") sddm.reboot()
            else { cmdFeedback.text = "reboot"; root.mode = "login"; pwd.forceActiveFocus() }
        } else if (cmd === "p" || cmd === "power" || cmd === "q" || cmd === "quit") {
            if (typeof sddm !== "undefined") sddm.powerOff()
            else { cmdFeedback.text = "power off"; root.mode = "login"; pwd.forceActiveFocus() }
        } else if (cmd === "s" || cmd === "session") { openPicker("session-pick") }
        else if (cmd === "u" || cmd === "user")      { openPicker("user-pick")    }
        else if (cmd === "") {
            root.mode = "login"; root.cmdBuf = ""; cmdInput.text = ""
            cmdFeedback.text = ""; pwd.forceActiveFocus()
        } else {
            cmdFeedback.text = "E492: not a command: " + cmd
            root.mode = "login"; root.cmdBuf = ""; cmdInput.text = ""
            pwd.forceActiveFocus()
        }
    }

    function doLogin() {
        var u = userListModel.count > root.userIndex
                ? userListModel.get(root.userIndex).login
                : (typeof userModel !== "undefined" ? userModel.lastUser : "")
        if (typeof sddm !== "undefined") sddm.login(u, pwd.text, typeof sessionModel !== "undefined" ? sessionModel.lastIndex : root.sessionIndex)
    }
}

